import json
import os
print("Pre-Import")
from stockfish import Stockfish

stockfish = Stockfish("./stockfish/__init__.py")
def lambda_handler(event, context):
    # TODO implement
    print("Passed Imports")
    user_id = event['user_id']
    current_fen = event['fen']

    stockfish.set_elo_rating(os.environ['elo'])
    stockfish.set_fen_position(current_fen)

    best_move = stockfish.get_best_move()
    return {
        'user_id': {user_id},
        'best_move': {best_move}
        }